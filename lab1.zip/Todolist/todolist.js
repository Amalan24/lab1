let todo=[];

function add(){
    todo.push(input.value);
    addtodo(input.value);
    input.value = "";
}

let todoList = document.getElementById('task');
function addtodo(todos){
    let para = document.createElement('p');
    para.innerHTML = todos;
    list.appendChild(para);
}