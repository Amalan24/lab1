const taskInput = document.getElementById("task");
const taskList = document.getElementById("list");

let tasks = [];

function add() {
    const task = taskInput.value;
    tasks.push(task);
    updateTaskList();
    taskInput.value = "";
}

function updateTaskList() {
    taskList.value = "";
    tasks.forEach((task) => {
    taskList.value += "- " + task + "\n";
    });
}

function showNext() {
    const nextTask = tasks.shift();
    const nextTaskInput = document.getElementById("next_task");
    nextTaskInput.value = nextTask;
    updateTaskList();
}