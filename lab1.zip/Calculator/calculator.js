let outputScreen = document.getElementById("output");
function display(num){
    if(outputScreen.value!="Invalid"){
        outputScreen.value += num;
    }
}
function equals(){
    try{
        outputScreen.value = eval(outputScreen.value);
    }
    catch(err){
        outputScreen.value="Invalid";
    }
}

function clr(){
    outputScreen.value = "";
}
function del(){
    outputScreen.value=outputScreen.value.slice(0,-1);
}

function percent(){
    outputScreen.value = outputScreen.value/100;
}

function square(){
    outputScreen.value = Math.pow(outputScreen.value,2);
}
function cube(){
    outputScreen.value = Math.pow(outputScreen.value,3);
}
function factorial(){
    let fact = 1;
    if(outputScreen.value>=0){
        for(let i=1;i<=outputScreen.value;i++){
            fact*=i;
        }
        outputScreen.value = fact;
    }
    else{
        outputScreen.value="Invalid";
    }
}