//Q1 - Validating phone number

function checkNum(number){
    let re = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})/;
    return re.test(number);
}

let number = prompt("Enter phone number : ");
console.log(checkNum(number));

//Q2 - Validating a phone number anywhere in a sentence

/*function containsPhone(text){
    let reg  = /\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})/;
    return reg.test(text);
}

let sentence = prompt("Enter text : ");
console.log(containsPhone(sentence));*/